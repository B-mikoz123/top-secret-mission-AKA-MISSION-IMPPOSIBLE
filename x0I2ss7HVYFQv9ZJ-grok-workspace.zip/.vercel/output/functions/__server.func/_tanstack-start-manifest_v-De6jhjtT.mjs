//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-De6jhjtT.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-jGYSI1pE.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-jGYSI1pE.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CZGbWUx4.js"]
	}
} });
//#endregion
export { tsrStartManifest };
