import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-r9rqkrL-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var letter = {
	greeting: "My dearest M'lady,",
	occasion: "For your 18th birthday",
	paragraphs: [
		"Happy 18th birthday. I hope today feels as warm as candlelight, and as bright as the little lights that drifted in just to sit with you.",
		"You are the kind of person a real letter is for. Thank you for the way you laugh, the way you stay, and the way a room feels kinder the moment you are in it.",
		"Eighteen looks good on you. May this year open gently, may every wish you make over this cake find its way back to you, and may you always know how deeply you are loved."
	],
	closing: "With all my heart,",
	signature: "The one who thinks you're The Best"
};
var GIF = "https://media1.tenor.com/m/BQVULwR8-TYAAAAC/dance-chibi.gif";
function BirthdayScene() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const titleId = (0, import_react.useId)();
	const openButton = (0, import_react.useRef)(null);
	const closeButton = (0, import_react.useRef)(null);
	const wasOpen = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (open) {
			wasOpen.current = true;
			closeButton.current?.focus();
			const onKey = (event) => {
				if (event.key === "Escape") setOpen(false);
			};
			window.addEventListener("keydown", onKey);
			return () => window.removeEventListener("keydown", onKey);
		}
		if (wasOpen.current) openButton.current?.focus();
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "sky",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": "true",
				children: Array.from({ length: 8 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "firefly" }, index))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "stage",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "banner",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "Her 18th"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Happy 18th Birthday, M'lady!" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "lede",
							children: "The letter is in the middle of the cake. Tap it when you want to read."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "layout",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
						className: "portrait",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hat",
								"aria-hidden": "true",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hat-pom" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hat-band" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "gif-frame",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: GIF,
									alt: "Chibi Kaoruko dancing in a party mood"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", { children: [
								"Dancing along ·",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "https://tenor.com/view/dance-chibi-kaoruko-gif-361787905988688182",
									target: "_blank",
									rel: "noreferrer",
									children: "Tenor"
								})
							] })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "still",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "cake",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sr-only",
									children: "An 18th birthday cake with a letter in the middle."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "cake-glow",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "stand-foot",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "stand-stem",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "plate",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tier tier-base",
									"aria-hidden": "true",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "icing" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "drip d1" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "drip d2" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "drip d3" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "drip d4" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "drip d5" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ribbon" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pearl p1" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pearl p2" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pearl p3" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pearl p4" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "age-mark",
											children: "18"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "tier tier-top",
									"aria-hidden": "true",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "icing icing-top" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "drip d1" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "drip d2" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "drip d3" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "drip d4" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "sprinkle a" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "sprinkle b" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "sprinkle c" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "sprinkle d" })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "candles",
									"aria-hidden": "true",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "candle",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "wick" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "flame" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "candle",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "wick" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "flame" })]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									ref: openButton,
									type: "button",
									className: "cake-letter",
									"aria-haspopup": "dialog",
									"aria-expanded": open,
									"aria-label": "Open the letter",
									onClick: () => setOpen(true),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "note",
										"aria-hidden": "true",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
											className: "envelope-svg",
											viewBox: "0 0 120 78",
											focusable: "false",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
													className: "env-body",
													x: "3.5",
													y: "3.5",
													width: "113",
													height: "71",
													rx: "5"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
													className: "env-fold",
													points: "6,6 60,40 114,6"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
													className: "env-fold",
													points: "6,72 60,40 114,72"
												})
											]
										})
									})
								})
							]
						})
					})]
				})]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "veil",
				onClick: () => setOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "sheet",
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": titleId,
					onClick: (event) => event.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sheet-top",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "monogram",
								"aria-hidden": "true",
								children: "18"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								ref: closeButton,
								type: "button",
								className: "fold",
								onClick: () => setOpen(false),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
									size: 16,
									"aria-hidden": "true"
								}), "Fold it closed"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: titleId,
							children: letter.greeting
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "date-line",
							children: letter.occasion
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rule" }),
						letter.paragraphs.map((paragraph) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: paragraph }, paragraph)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "signoff",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: letter.closing }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "name",
								children: letter.signature
							})]
						})
					]
				})
			}) : null
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BirthdayScene, {});
}
//#endregion
export { Home as component };
