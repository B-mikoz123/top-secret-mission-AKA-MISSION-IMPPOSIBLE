// ============================================================
//  EDIT THIS FILE to change the letter.
//  File: src/edit-this-letter.ts
//  Change the words below, then save. The letter on the cake
//  uses only this file.
// ============================================================

export const letter = {
  greeting: "My dearest M'lady,",
  occasion: "For your 18th birthday",
  paragraphs: [
    "Happy 18th birthday. I hope today feels as warm as candlelight, and as bright as the little lights that drifted in just to sit with you.",
    "You are the kind of person a real letter is for. Thank you for the way you laugh, the way you stay, and the way a room feels kinder the moment you are in it.",
    "Eighteen looks good on you. May this year open gently, may every wish you make over this cake find its way back to you, and may you always know how deeply you are loved.",
  ],
  closing: "With all my heart,",
  signature: "The one who thinks you're The Best",
};
