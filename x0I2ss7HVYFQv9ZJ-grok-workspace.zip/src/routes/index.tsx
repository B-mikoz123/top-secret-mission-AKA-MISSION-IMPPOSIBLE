import { createFileRoute } from "@tanstack/react-router";
import { BirthdayScene } from "@/components/birthday-scene";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <BirthdayScene />;
}
