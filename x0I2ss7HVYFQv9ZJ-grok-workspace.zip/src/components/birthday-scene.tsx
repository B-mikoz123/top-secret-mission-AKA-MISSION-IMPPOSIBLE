import { useEffect, useId, useRef, useState } from "react";
import { X } from "lucide-react";
import { letter } from "@/edit-this-letter";

const GIF =
  "https://media1.tenor.com/m/BQVULwR8-TYAAAAC/dance-chibi.gif";

export function BirthdayScene() {
  const [open, setOpen] = useState(false);
  const titleId = useId();
  const openButton = useRef<HTMLButtonElement>(null);
  const closeButton = useRef<HTMLButtonElement>(null);
  const wasOpen = useRef(false);

  useEffect(() => {
    if (open) {
      wasOpen.current = true;
      closeButton.current?.focus();
      const onKey = (event: KeyboardEvent) => {
        if (event.key === "Escape") setOpen(false);
      };
      window.addEventListener("keydown", onKey);
      return () => window.removeEventListener("keydown", onKey);
    }
    if (wasOpen.current) openButton.current?.focus();
  }, [open]);

  return (
    <div className="sky">
      <div aria-hidden="true">
        {Array.from({ length: 8 }, (_, index) => (
          <span key={index} className="firefly" />
        ))}
      </div>

      <main className="stage">
        <header className="banner">
          <p className="eyebrow">Her 18th</p>
          <h1>Happy 18th Birthday, M'lady!</h1>
          <p className="lede">
            The letter is at the bottom of the cake. Tap it when you want to read.
          </p>
        </header>

        <div className="layout">
          <figure className="portrait">
            <div className="hat" aria-hidden="true">
              <span className="hat-pom" />
              <span className="hat-band" />
            </div>
            <div className="gif-frame">
              <img src={GIF} alt="Chibi Kaoruko dancing in a party mood" />
            </div>
            <figcaption>
              Dancing along ·{" "}
              <a
                href="https://tenor.com/view/dance-chibi-kaoruko-gif-361787905988688182"
                target="_blank"
                rel="noreferrer"
              >
                Tenor
              </a>
            </figcaption>
          </figure>

          <div className="still">
            <div className="cake">
              <span className="sr-only">
                An 18th birthday cake. The candles are the numbers 1 and 8, and a letter sits at the bottom.
              </span>
              <div className="cake-glow" aria-hidden="true" />
              <div className="stand-foot" aria-hidden="true" />
              <div className="stand-stem" aria-hidden="true" />
              <div className="plate" aria-hidden="true" />

              <div className="tier tier-base" aria-hidden="true">
                <span className="icing" />
                <span className="drip d1" />
                <span className="drip d2" />
                <span className="drip d3" />
                <span className="drip d4" />
                <span className="drip d5" />
                <span className="ribbon" />
                <span className="pearl p1" />
                <span className="pearl p2" />
                <span className="pearl p3" />
                <span className="pearl p4" />
              </div>

              <div className="tier tier-top" aria-hidden="true">
                <span className="icing icing-top" />
                <span className="drip d1" />
                <span className="drip d2" />
                <span className="drip d3" />
                <span className="drip d4" />
                <span className="sprinkle a" />
                <span className="sprinkle b" />
                <span className="sprinkle c" />
                <span className="sprinkle d" />
              </div>

              <div className="candles" aria-hidden="true">
                <span className="numeral">
                  <span className="flame" />
                  <span className="digit">1</span>
                </span>
                <span className="numeral">
                  <span className="flame" />
                  <span className="digit">8</span>
                </span>
              </div>

              <button
                ref={openButton}
                type="button"
                className="cake-letter"
                aria-haspopup="dialog"
                aria-expanded={open}
                aria-label="Open the letter"
                onClick={() => setOpen(true)}
              >
                <span className="note" aria-hidden="true">
                  <svg className="envelope-svg" viewBox="0 0 120 78" focusable="false">
                    <rect
                      className="env-body"
                      x="3.5"
                      y="3.5"
                      width="113"
                      height="71"
                      rx="5"
                    />
                    <polyline
                      className="env-fold"
                      points="6,6 60,40 114,6"
                    />
                    <polyline
                      className="env-fold"
                      points="6,72 60,40 114,72"
                    />
                    <g className="env-flower" transform="translate(60 40)">
                      <circle className="env-petal" cx="0" cy="-9" r="6.5" />
                      <circle className="env-petal" cx="8.6" cy="-2.8" r="6.5" />
                      <circle className="env-petal" cx="5.3" cy="7.3" r="6.5" />
                      <circle className="env-petal" cx="-5.3" cy="7.3" r="6.5" />
                      <circle className="env-petal" cx="-8.6" cy="-2.8" r="6.5" />
                      <circle className="env-bloom" r="4.2" />
                    </g>
                  </svg>
                </span>
              </button>
            </div>
          </div>
        </div>
      </main>

      {open ? (
        <div className="veil" onClick={() => setOpen(false)}>
          <article
            className="sheet"
            role="dialog"
            aria-modal="true"
            aria-labelledby={titleId}
            onClick={(event) => event.stopPropagation()}
          >
            <div className="sheet-top">
              <div className="monogram" aria-hidden="true">
                18
              </div>
              <button
                ref={closeButton}
                type="button"
                className="fold"
                onClick={() => setOpen(false)}
              >
                <X size={16} aria-hidden="true" />
                Fold it closed
              </button>
            </div>
            <h2 id={titleId}>{letter.greeting}</h2>
            <p className="date-line">{letter.occasion}</p>
            <div className="rule" />
            {letter.paragraphs.map((paragraph) => (
              <p key={paragraph}>{paragraph}</p>
            ))}
            <div className="signoff">
              <p>{letter.closing}</p>
              <p className="name">{letter.signature}</p>
            </div>
          </article>
        </div>
      ) : null}
    </div>
  );
}
